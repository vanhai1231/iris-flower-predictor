import { A, e } from "./mermaid-parser.core.D9w5gg-F.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
