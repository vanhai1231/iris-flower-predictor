import { P, a } from "./mermaid-parser.core.D9w5gg-F.js";
export {
  P as PacketModule,
  a as createPacketServices
};
