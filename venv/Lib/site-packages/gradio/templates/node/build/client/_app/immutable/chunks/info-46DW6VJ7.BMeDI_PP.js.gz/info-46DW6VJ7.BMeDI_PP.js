import { I, c } from "./mermaid-parser.core.D9w5gg-F.js";
export {
  I as InfoModule,
  c as createInfoServices
};
