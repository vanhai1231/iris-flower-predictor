import { a0, $ } from "../chunks/2.BJK_No9S.js";
export {
  a0 as component,
  $ as universal
};
